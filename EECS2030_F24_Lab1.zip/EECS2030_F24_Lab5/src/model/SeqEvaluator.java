package model;

public class SeqEvaluator {

	public void addOperation(String string, int[] seq1, int[] seq2) {
		// TODO Auto-generated method stub
		
	}

}
