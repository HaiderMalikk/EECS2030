package model;

public class SumsOfPrefixes extends SeqOperation {

	public SumsOfPrefixes(int[] seq2) {
		// TODO Auto-generated constructor stub
	}

}
