package model;

public class SeqOperation {

}
