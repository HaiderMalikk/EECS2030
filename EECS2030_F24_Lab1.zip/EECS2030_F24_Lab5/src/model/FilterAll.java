package model;

public class FilterAll extends SeqEvaluator {

	public FilterAll(int i) {
		// TODO Auto-generated constructor stub
	}

}
