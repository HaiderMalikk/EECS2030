package model;

public class ConcatAll extends SeqEvaluator {

	public ConcatAll(int i) {
		// TODO Auto-generated constructor stub
	}

}
