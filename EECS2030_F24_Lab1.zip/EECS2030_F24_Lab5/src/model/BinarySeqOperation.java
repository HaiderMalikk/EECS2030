package model;

public class BinarySeqOperation {

}
