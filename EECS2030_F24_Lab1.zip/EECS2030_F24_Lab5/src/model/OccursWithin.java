package model;

public class OccursWithin extends BinarySeqOperation {

}
