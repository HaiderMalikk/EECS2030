package model;

public class Projection extends BinarySeqOperation {


	public Projection(int[] seq1a, int[] seq2) {
		// TODO Auto-generated constructor stub
	}

}
